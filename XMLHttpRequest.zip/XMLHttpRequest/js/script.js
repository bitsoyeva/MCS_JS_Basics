
const inputCity=document.getElementsByName('city')
const city=inputCity.value;
const APIKey = 'd456520b1eabc83b97fa64a554b3bb39';
//const city = 'Москва';
const url = 'https://api.openweathermap.org/data/2.5/weather?q='+city+'&appid='+APIKey;
let xhr = new XMLHttpRequest();
xhr.open('GET', url, false);
xhr.send();

form.onsubmit = function(){
	if (xhr.status != 200) {
		insert.innerHTML=(xhr.status + ''+ xhr.statusText);
	} else {
		let DATA = JSON.parse(xhr.responseText);
		insert.innerHTML=DATA.main.temp - 273;
	}
}